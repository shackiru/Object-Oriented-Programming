package com.example.finalproject;

import javax.imageio.plugins.jpeg.JPEGImageReadParam;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.border.Border;
import org.w3c.dom.Text;
import org.w3c.dom.events.MouseEvent;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Payment extends JFrame implements ActionListener{
    private Font fontTitle = new Font(Font.DIALOG, Font.BOLD, 20);

    private JPanel westPanel = new JPanel();
    private JPanel navNorthPanel = new JPanel();
    private JLabel logoLabel = new JLabel("LOGO");
    private JPanel navSouthPanel = new JPanel();
    private JPanel navCenterPanel = new JPanel();
    private JPanel navCenterNorthJPanel = new JPanel();
    private JPanel navCenterEastJPanel = new JPanel();
    private JPanel navCenterWestJPanel = new JPanel();
    private JPanel navCenterSouthJPanel = new JPanel();
    private JPanel navLinksPanel = new JPanel();
    private JButton homeButton = new JButton("Home");
    private JButton myGameButton = new JButton("My Game");
    private JButton buyGameButton = new JButton("Buy Game");
    private JButton cartButton = new JButton("Cart");
    private ArrayList<cartData> carts = new ArrayList<>();
    private JPanel eastPanel = new JPanel();
    private JPanel homeTop = new JPanel();
    private JPanel homeLeft = new JPanel();
    private JPanel homeRight = new JPanel();
    private JPanel homeBottom = new JPanel();
    private JPanel homeCenter = new JPanel();
    private JPanel adminInfoJPanel = new JPanel();
    private JPanel adminInfoTopJPanel = new JPanel();
    private JLabel paymentLabel = new JLabel("Invoice");
    private JPanel adminInfoDownJPanel = new JPanel();
    private JButton cancelButton = new JButton("Cancel");
    private JButton paymentButton = new JButton("Payment");
    private JPanel adminInfoCenterJPanel = new JPanel();

    private JLabel nameLabel = new JLabel();
    private JLabel publisherLabel = new JLabel();
    private JLabel priceLabel = new JLabel();
    private JLabel quantityLabel = new JLabel();
    private JLabel taxLabel = new JLabel("Total Tax                	: Tax");
    private JLabel totalLabel = new JLabel("Total Price             	: Total");

    public void initComp() {

        // TODO Auto-generated method stub
        setLayout(new BorderLayout());

        westPanel.setLayout(new BoxLayout(westPanel, BoxLayout.Y_AXIS));

        navNorthPanel.setLayout(new BoxLayout(navNorthPanel, BoxLayout.Y_AXIS));
        navNorthPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        navNorthPanel.add(Box.createVerticalGlue());
        navNorthPanel.setPreferredSize(new Dimension(WIDTH, 100));
        logoLabel.setFont(new Font(getName(), ABORT, 20));
        navNorthPanel.add(logoLabel);
        navNorthPanel.add(Box.createVerticalGlue());
        navNorthPanel.setBackground(Color.gray);
        westPanel.add(navNorthPanel);

        navCenterPanel.setLayout(new BorderLayout());
        navCenterNorthJPanel.setLayout(new FlowLayout());
        navCenterEastJPanel.setLayout(new FlowLayout());
        navCenterEastJPanel.setSize(new Dimension(200, WIDTH));
        navCenterWestJPanel.setLayout(new FlowLayout());
        navCenterSouthJPanel.setLayout(new FlowLayout());
        navCenterNorthJPanel.setBackground(Color.GRAY);
        navCenterEastJPanel.setBackground(Color.GRAY);
        navCenterSouthJPanel.setBackground(Color.GRAY);
        navCenterWestJPanel.setBackground(Color.GRAY);
        navCenterPanel.add(navCenterNorthJPanel, "North");
        navCenterPanel.add(navCenterEastJPanel, "East");
        navCenterPanel.add(navCenterSouthJPanel, "South");
        navCenterPanel.add(navCenterWestJPanel, "West");

//		navCenterPanel.setLayout(new BoxLayout(navCenterPanel, BoxLayout.Y));
        navLinksPanel.setLayout(new GridLayout(0, 1, 0, 10) );
        navLinksPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        homeButton.setFont(new Font(getName(), ABORT, 15));
//		homeButton.setSize(300, 300);
//		homeButton.setPreferredSize(new Dimension(navCenterPanel.getWidth()/2, navCenterPanel.getHeight()/2));
        navLinksPanel.add(homeButton);
        myGameButton.setFont(new Font(getName(), ABORT, 15));
        navLinksPanel.add(myGameButton);
        buyGameButton.setFont(new Font(getName(), ABORT, 15));
        navLinksPanel.add(buyGameButton);
        cartButton.setFont(new Font(getName(), ABORT, 15));
        navLinksPanel.add(cartButton);
        navLinksPanel.setPreferredSize(new Dimension(100, 500));
        navLinksPanel.setBackground(Color.GRAY);

        navCenterPanel.add(navLinksPanel, "Center");
        navCenterPanel.setBackground(Color.gray);
        westPanel.add(navCenterPanel);

        navSouthPanel.setLayout(new FlowLayout());
        navSouthPanel.setBackground(Color.gray);
        navSouthPanel.setPreferredSize(new Dimension(WIDTH, 100));
        westPanel.add(navSouthPanel);

        westPanel.setPreferredSize(new Dimension(267, HEIGHT));
        westPanel.setBackground(Color.GRAY);
        add(westPanel, "West");


        //EASTTTT
        eastPanel.setLayout(new BorderLayout());
        homeTop.setPreferredSize(new Dimension(WIDTH, 50));
        homeBottom.setPreferredSize(new Dimension(WIDTH, 50));
        homeLeft.setPreferredSize(new Dimension(80, HEIGHT));
        homeRight.setPreferredSize(new Dimension(80, HEIGHT));
        eastPanel.add(homeTop, "North");
        eastPanel.add(homeRight, "East");
        eastPanel.add(homeBottom, "South");
        eastPanel.add(homeLeft, "West");
        homeCenter.setLayout(new GridLayout(1, 2));

        //INFO
        adminInfoJPanel.setLayout(new BorderLayout());
        adminInfoTopJPanel.setPreferredSize(new Dimension(WIDTH, 150));
        adminInfoTopJPanel.setBorder(BorderFactory.createEmptyBorder(75, 0, 0, 30));
        adminInfoJPanel.add(adminInfoTopJPanel, "North");
        paymentLabel.setFont(fontTitle);
        adminInfoTopJPanel.add(paymentLabel);
        adminInfoJPanel.add(adminInfoCenterJPanel, "Center");
        adminInfoCenterJPanel.setLayout(new GridLayout(6,2));
        adminInfoCenterJPanel.setBorder(BorderFactory.createEmptyBorder(0, 118, 0, 0));
        adminInfoJPanel.add(adminInfoDownJPanel, "South");
        adminInfoDownJPanel.setPreferredSize(new Dimension(WIDTH, 200));
        cancelButton.setPreferredSize(new Dimension(100,30));
        cancelButton.addActionListener(this);
        paymentButton.setPreferredSize(new Dimension(100,30));
        paymentButton.addActionListener(this);
        adminInfoDownJPanel.add(cancelButton);
        adminInfoDownJPanel.add(paymentButton);
        adminInfoDownJPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 20));

        homeCenter.add(adminInfoJPanel);

        homeCenter.setBackground(Color.black);
        eastPanel.add(homeCenter, "Center");

        adminInfoCenterJPanel.add(nameLabel);
        adminInfoCenterJPanel.add(publisherLabel);
        adminInfoCenterJPanel.add(priceLabel);
        adminInfoCenterJPanel.add(quantityLabel);
        adminInfoCenterJPanel.add(taxLabel);
        adminInfoCenterJPanel.add(totalLabel);
        for(cartData i : carts)
        {
            String gameTxt = nameLabel.getText();
            String publisherTxt = publisherLabel.getText();
            String priceTxt = priceLabel.getText();
            String quantityTxt = quantityLabel.getText();
            gameTxt = i.getGameTitle();
            publisherTxt = i.getGamePublisher();
            priceTxt = Integer.toString(i.getGamePrice());

            nameLabel.setText("Game Title: " + gameTxt);
            publisherLabel.setText("Publisher: " + publisherTxt);
            priceLabel.setText("Price: " + priceTxt);
        }

        eastPanel.setBackground(Color.BLUE);
        eastPanel.setPreferredSize(new Dimension(620, HEIGHT));
        add(eastPanel, "East");


    }


    public Payment(ArrayList<cartData> carts) {
        this.carts = carts;
        initComp();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 700);
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }


    public static void main(String[] args) {
        ArrayList<cartData> cart = new ArrayList<>();
        Payment payment = new Payment(cart);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        // TODO Auto-generated method stub
        if (e.getSource().equals(paymentButton)) {
            int response = JOptionPane.showConfirmDialog(this, "Are you sure?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if(response == JOptionPane.YES_OPTION){
                JOptionPane.showMessageDialog(null, "Your payment was successful!", "Payment Success", JOptionPane.NO_OPTION);
            } else if(response == JOptionPane.NO_OPTION){
                JOptionPane.showMessageDialog(null, "Sorry, we couldn't process your payment", "Payment Unsuccess", JOptionPane.NO_OPTION);
            } else if(response == JOptionPane.OK_CANCEL_OPTION){
                JOptionPane.showMessageDialog(null, "", "Cancel", JOptionPane.OK_CANCEL_OPTION);
            }
        } else if(e.getSource().equals(cancelButton)){
            int response = JOptionPane.showConfirmDialog(this, "Are you sure?", "Cancel", JOptionPane.CANCEL_OPTION);
        }
    }

}

