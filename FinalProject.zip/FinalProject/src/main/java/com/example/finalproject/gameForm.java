package com.example.finalproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class gameForm extends JFrame implements ActionListener
{
    private JPanel westPanel = new JPanel();
    private JPanel midPanel = new JPanel();
    private JLabel nameLabel = new JLabel("Name");
    private JLabel genreLabel = new JLabel("Genre");
    private JLabel quantityLabel = new JLabel("Quantity");
    private JLabel priceLabel = new JLabel("Price");
    private JLabel publisherLabel = new JLabel("Publisher");
    private JTextField tfGame = new JTextField();
    private JComboBox jcbPublisher = new JComboBox();
    private JTextField tfPrice = new JTextField();
    private JTextField tfQuantity = new JTextField();
    private JComboBox jcbGenre = new JComboBox();
    public void initComp()
    {
        westPanel.setLayout(new BoxLayout(westPanel, BoxLayout.Y_AXIS));
        westPanel.add(nameLabel);
        westPanel.add(genreLabel);
        westPanel.add(quantityLabel);
        westPanel.add(priceLabel);
        westPanel.add(publisherLabel);
        midPanel.setLayout(new GridLayout());
        midPanel.add(tfGame);
    }
    public gameForm()
    {
        this.initComp();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 700);
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(new Runnable()
        {
            @Override
            public void run()
            {
                new gameForm();
            }
        });
    }
    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
