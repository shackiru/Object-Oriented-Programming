package com.example.finalproject;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class buyGame extends JFrame implements ActionListener
{
    private JPanel westPanel = new JPanel();

    private JPanel navNorthPanel = new JPanel();
    private JLabel logoLabel = new JLabel("LOGO");

    private JPanel navSouthPanel = new JPanel();

    private JPanel navCenterPanel = new JPanel();

    private JPanel navCenterNorthJPanel = new JPanel();
    private JPanel navCenterEastJPanel = new JPanel();
    private JPanel navCenterWestJPanel = new JPanel();
    private JPanel navCenterSouthJPanel = new JPanel();
    private JPanel navLinksPanel = new JPanel();
    private JButton homeButton = new JButton("Home");
    private JButton myGameButton = new JButton("My Game");
    private JButton buyGameButton = new JButton("Buy Game");
    private JButton cartButton = new JButton("Cart");

    private JPanel cartPanel = new JPanel();
    private JPanel cartWest = new JPanel();
    private JPanel cartEast = new JPanel();
    private JPanel cartNorth = new JPanel();
    private JPanel cartSouth = new JPanel();
    private JPanel cartMid = new JPanel();
    private JPanel northNorth = new JPanel();
    private JPanel northNorthEast = new JPanel();
    private JPanel northNorthMid = new JPanel();
    private JPanel northNorthWest = new JPanel();
    private JPanel northSouth = new JPanel();
    private JPanel northEast = new JPanel();
    private JPanel northWest = new JPanel();
    private JSlider priceSlider = new JSlider();

    private JLabel labelSearch = new JLabel("Search Game:");
    private JTextField tfGame = new JTextField();
    private JComboBox comboSort = new JComboBox();
    private String[][] gameData =
            {
                    {"A001", "Pacman", "Basic", "4", "10000", "Unknown"},
                    {"A002", "Minecraft", "Creative","6", "100000", "Java"},
                    {"A003", "Chess", "-", "1", "20000", "Unknown"},
                    {"A001", "FIFA 2023", "Sports", "19", "320000", "EA Sports"},
                    {"A001", "NBA 2K", "Sports", "41", "320000", "EA Sports"},
                    {"A001", "Valorant", "FPS", "4", "32000", "Riot Games"},
                    {"A002", "Dota 2", "MOBA", "3", "40000", "Valve"}
            };
    private String[] tableTitle = {"ID", "Name", "Genre", "Quantity", "Price", "Publisher", "Select"};
    private DefaultTableModel model = new DefaultTableModel(gameData, tableTitle)
    {
        @Override
        public boolean isCellEditable(int row, int column)
        {
            return column == 6;
        }
    };
    private JTable gameTable = new JTable(model)
    {
        @Override
        public Class getColumnClass(int column)
        {
            switch(column)
            {
                case 0:
                    return String.class;
                case 1:
                    return String.class;
                case 2:
                    return String.class;
                case 3:
                    return String.class;
                case 4:
                    return String.class;
                case 5:
                    return String.class;
                default:
                    return Boolean.class;
            }
        }
    };
    private JScrollPane scrollTable = new JScrollPane(gameTable);
    private JPanel eastPanel = new JPanel();
    private JButton addToCart = new JButton("Add to cart");

    private JPanel southEast = new JPanel();
    private JPanel southMid = new JPanel();
    private JPanel southWest = new JPanel();

    public void initComp()
    {
        westPanel.setLayout(new BoxLayout(westPanel, BoxLayout.Y_AXIS));
//		westPanel.setBackground(Color.cyan);

        navNorthPanel.setLayout(new BoxLayout(navNorthPanel, BoxLayout.Y_AXIS));
        navNorthPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        navNorthPanel.add(Box.createVerticalGlue());
        navNorthPanel.setPreferredSize(new Dimension(WIDTH, 100));
        logoLabel.setFont(new Font(getName(), ABORT, 20));
        navNorthPanel.add(logoLabel);
        navNorthPanel.add(Box.createVerticalGlue());
        navNorthPanel.setBackground(Color.gray);
        westPanel.add(navNorthPanel);

        navCenterPanel.setLayout(new BorderLayout());
        navCenterNorthJPanel.setLayout(new FlowLayout());
        navCenterEastJPanel.setLayout(new FlowLayout());
        navCenterEastJPanel.setSize(new Dimension(200, WIDTH));
//		navCenterEastJPanel.setBackground(Color.red);
        navCenterWestJPanel.setLayout(new FlowLayout());
        navCenterSouthJPanel.setLayout(new FlowLayout());
        navCenterPanel.add(navCenterNorthJPanel, "North");
        navCenterPanel.add(navCenterEastJPanel, "East");
        navCenterPanel.add(navCenterSouthJPanel, "South");
        navCenterPanel.add(navCenterWestJPanel, "West");

//		navCenterPanel.setLayout(new BoxLayout(navCenterPanel, BoxLayout.Y));
        navLinksPanel.setLayout(new GridLayout(0, 1, 0, 10) );
        navLinksPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        homeButton.setFont(new Font(getName(), ABORT, 15));
//		homeButton.setSize(300, 300);
//		homeButton.setPreferredSize(new Dimension(navCenterPanel.getWidth()/2, navCenterPanel.getHeight()/2));
        navLinksPanel.add(homeButton);
        myGameButton.setFont(new Font(getName(), ABORT, 15));
        navLinksPanel.add(myGameButton);
        buyGameButton.setFont(new Font(getName(), ABORT, 15));
        navLinksPanel.add(buyGameButton);
        cartButton.setFont(new Font(getName(), ABORT, 15));
        navLinksPanel.add(cartButton);
        navLinksPanel.setPreferredSize(new Dimension(100, 500));
//        navLinksPanel.setBackground(Color.GRAY);

        navCenterPanel.add(navLinksPanel, "Center");
//        navCenterPanel.setBackground(Color.gray);
        westPanel.add(navCenterPanel);

        navSouthPanel.setLayout(new FlowLayout());
//        navSouthPanel.setBackground(Color.gray);
        navSouthPanel.setPreferredSize(new Dimension(WIDTH, 100));
        westPanel.add(navSouthPanel);

        westPanel.setPreferredSize(new Dimension(267, HEIGHT));
//        westPanel.setBackground(Color.gray);
        add(westPanel, "West");

        eastPanel.setLayout(new BorderLayout());

        eastPanel.setBackground(Color.BLUE);
        eastPanel.setPreferredSize(new Dimension(620, HEIGHT));
        add(eastPanel, "East");

//        cartPanel.setLayout(new BorderLayout());
        eastPanel.add(cartEast, "East");
        cartEast.setPreferredSize(new Dimension(20, HEIGHT));

        eastPanel.add(cartWest, "West");
        cartWest.setPreferredSize(new Dimension(20, HEIGHT));

        eastPanel.add(cartNorth, "North");
        cartNorth.setLayout(new BorderLayout());
        cartNorth.setBorder(BorderFactory.createEmptyBorder(25, 25, 10 , 25));

        cartNorth.add(northNorth, "North");
        northNorth.setLayout(new BorderLayout());

        northNorth.add(northNorthEast, "East");
        northNorthEast.setLayout(new FlowLayout());
        northNorthEast.add(logoLabel);

        northNorth.add(northNorthMid, "Center");
        northNorthMid.setLayout(new FlowLayout());

        northNorth.add(northNorthWest, "West");
        northNorthWest.setLayout(new FlowLayout());

        cartNorth.add(northSouth, "South");
        northSouth.setLayout(new GridLayout(1, 0, 10, 0));
        northSouth.add(labelSearch);
        northSouth.add(tfGame);
        northSouth.add(priceSlider);
        northSouth.add(comboSort);

        cartNorth.add(northEast, "East");
        northEast.setLayout(new FlowLayout());

        cartNorth.add(northWest, "West");
        northWest.setLayout(new FlowLayout());

        eastPanel.add(cartSouth, "South");
        cartSouth.setLayout(new BorderLayout());
        cartSouth.setBorder(BorderFactory.createEmptyBorder(25, 25, 10 , 25));
        cartSouth.setPreferredSize(new Dimension(WIDTH, 100));
        cartSouth.add(southEast, "East");
        cartSouth.add(southMid, "Center");
        cartSouth.add(southWest, "West");
        southEast.add(addToCart);

        eastPanel.add(cartMid, "Center");
        cartMid.setLayout(new BorderLayout());
        gameTable.setBounds(30, 40, 600, 400);
        gameTable.getColumnModel().getColumn(0).setPreferredWidth(10);
        gameTable.getColumnModel().getColumn(1).setPreferredWidth(30);
        gameTable.getColumnModel().getColumn(2).setPreferredWidth(40);
        gameTable.getColumnModel().getColumn(3).setPreferredWidth(50);
        gameTable.getColumnModel().getColumn(4).setPreferredWidth(30);
        gameTable.getColumnModel().getColumn(5).setPreferredWidth(20);
        gameTable.getColumnModel().getColumn(6).setPreferredWidth(10);
        cartMid.add(scrollTable);


//        eastPanel.add(cartPanel);

    }

    public buyGame()
    {
        initComp();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 700);
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    public static void main(String[] args)
    {
        new buyGame();
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {

    }
}