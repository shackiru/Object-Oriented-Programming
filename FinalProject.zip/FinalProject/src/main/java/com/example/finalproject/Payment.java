package com.example.finalproject;

public class Payment {


        public Payment(){

        }

    public static void main(String[] args) {
        new Payment();
    }
}
