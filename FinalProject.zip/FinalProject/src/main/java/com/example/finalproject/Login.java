package com.example.finalproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JFrame implements ActionListener {
    private Font font_title = new Font(Font.DIALOG, Font.BOLD, 25);

    //    Header
    private JPanel panel_north = new JPanel();
    private  JLabel label_login = new JLabel("WELCOME");

    //    Component
    private JPanel panel_center = new JPanel();
    private JTextField text_username = new JTextField();
    private JPasswordField text_password = new JPasswordField();

    //    Footer
    private JPanel panel_south = new JPanel();
    private JButton btn_submit = new JButton("SUBMIT");
    private JButton btn_clear = new JButton("CLEAR");

    void  init_components(){
        setLayout(new BorderLayout());

    //  Header
        panel_north.setLayout(new FlowLayout());
        label_login.setFont(font_title);
        panel_north.add(label_login, BorderLayout.CENTER);

        // panel_north.setPreferredSize(new Dimension(50, 100));
        add(panel_north, BorderLayout.NORTH);
    //        panel_north.setBackground(Color.green);
    //        text_password.setBackground(Color.red);
    //        text_username.setBackground(Color.blue);

    //  Content
        panel_center.setLayout(new GridLayout(3, 2));
        panel_center.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        // panel_center.setLayout(new GridLayout(1,5));

    //  Row 1
        // panel_center.setPreferredSize(new Dimension(100, 100));
        panel_center.add(new JLabel("Username"));
        panel_center.add(text_username);
    //        panel_center.setBackground(Color.yellow);
        add(panel_center, "Center");

    //  Row 2
        panel_center.add(new JLabel("Password"));
        panel_center.add(text_password);
        add(panel_center, "Center");

    //  Footer
        panel_south.setLayout(new FlowLayout());
        btn_clear.setPreferredSize(new Dimension(140, 30));
        btn_clear.addActionListener(this);
        btn_submit.addActionListener(this);
        btn_submit.setPreferredSize(new Dimension(140, 30));
        panel_south.add(btn_submit);

        panel_south.add(btn_clear);
        add(panel_south, "South");

        setTitle("Login Page");
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(600, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public Login(){
        init_components();
    }

    public static void main(String[] args) {
        new Login();
    }

    public  void actionPerformed(ActionEvent e){
        Object obj = e.getSource();

        if(obj.equals(btn_submit)){
            String username = text_username.getText();
            String password = text_password.getText();
        }
    }
}